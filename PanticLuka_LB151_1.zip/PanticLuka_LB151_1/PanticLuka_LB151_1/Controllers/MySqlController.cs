﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MySql.Data.MySqlClient;
using System.Data;
using System.Configuration;
using PanticLuka_LB151_1.Models;
using System.Security.Cryptography;

namespace PanticLuka_LB151_1.Controllers
{
    public class MySqlController : Controller
    {
        // GET: MySql
        public ActionResult Index()
        {
            List<MySqlClass> list = new List<MySqlClass>();
            string mainconn = "server = 127.0.0.1; database = library; uid = root; password = 123456;";

            MySqlConnection conn = new MySqlConnection(mainconn);
            string query = "select * from books";
            MySqlCommand command= new MySqlCommand(query);
            command.Connection = conn ;
            conn.Open();
            MySqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                list.Add(new MySqlClass()
                {
                    title = reader["title"].ToString(),
                    genre= reader["genre"].ToString(),
               
                    author = reader["author"].ToString(),
                    publisher = reader["publisher"].ToString(),
                    language = reader["language"].ToString(),
                    

                });

            }
            conn.Close();
            return View(list);
        }
    }
}